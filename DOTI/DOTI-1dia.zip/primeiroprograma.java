public class primeiroprograma {
	public static void main(String[] args) {

		boolean verdadeiro = true;
		int numero = 10;
		String texto = "Andrei Faro";
		char caracter = 'B';
		double dinheiro = 12.90;
		System.out.println(verdadeiro);
		System.out.println(numero);
		System.out.println(texto);
		System.out.println(caracter);
		System.out.println(dinheiro);
	}
}