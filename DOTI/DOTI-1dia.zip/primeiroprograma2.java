public class segundoprograma {
	public static void main(String[] args) {
		int valA = 12;
		int valB = 10;
		int valC = valA + valB;

		System.out.println(valC);

	}

	public static int soma(int primeirovalor, int segundovalor) {
		int resultado = primeirovalor + segundovalor;
		}
}