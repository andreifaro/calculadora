public class segundoprograma {
	public static void main(String[] args) {

		int valA = programaentrada.entrada();
		int valB = programaentrada.entrada();
		int valC = programasoma.soma(valA, valB);
		int valD = programasubtracao.subtracao(valA, valB);
		int valE = programamultiplica.multiplicacao(valA, valB);
		double valF = programadivisao.divisao(valA, valB);

		System.out.println("O valor da Soma foi: " + valC);
		System.out.println("O valor da Subtracao foi: " + valD);
		System.out.println("O valor da Multiplicacao foi: " + valE);
		System.out.println("O valor da Divisao foi: " + valF);

	}

}

