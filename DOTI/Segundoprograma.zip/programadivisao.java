public class programadivisao {
public static int divisao(int primeirovalor, int segundovalor) {
		int resultado = primeirovalor / segundovalor;
		return resultado;
		}
	}