public class programamultiplica {
public static int multiplicacao(int primeirovalor, int segundovalor) {
		int resultado = primeirovalor * segundovalor;
		return resultado;
		}
	}