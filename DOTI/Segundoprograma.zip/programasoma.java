public class programasoma {
public static int soma(int primeirovalor, int segundovalor) {
		int resultado = primeirovalor + segundovalor;
		return resultado;
		}
	}