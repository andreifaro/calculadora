public class programasubtracao {
public static int subtracao(int primeirovalor, int segundovalor) {
		int resultado = primeirovalor - segundovalor;
		return resultado;
		}
	}