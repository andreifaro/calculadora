public class ImpostoErrado {

    // public double calcular(String nomeImposto, double valor) {

    // if (nomeImposto.equals("ISS")) {
    // return valor * 0.10;
    // } else if (nomeImposto.equals("ICMS")) {
    // return valor * 0.20;
    // } else if (nomeImposto.equals("IPI")) {
    // return valor * 0.50;
    // } else if (nomeImposto.equals("IRRF")) {
    // return valor * 0.275;
    // }
    // return 0;

    // }

    // public Imposto() {
    // }

}