

# Requisitos

1. Criar um programa Java
2. Recolher entradas do usuario a partir de um menu exibido
2.1 Criar uma empresa
2.2 Criar umm pessoa
2.2.1 Perguntar se ela possui Carro
2.2.2 Se possuir carro, informar dados sobre o carro
2.3 Contratar uma pessoa
2.4 Demitir uma pessoa a partir da sua matricula

