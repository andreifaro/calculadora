package impostos;

public class ProgramaImposto {

    // public static void main(String[] args) {

    // // Imposto imp = new Imposto(20);

    // IPI impostoIPI = new IPI(55);
    // ICMS impostoICMS = new ICMS(100);

    // double impostoPagarIPI = calculadoraDeImpostos(impostoIPI);
    // double impostoPagarICMS = calculadoraDeImpostos(impostoICMS);

    // System.out.println(impostoPagarICMS);
    // System.out.println(impostoPagarIPI);

    // }

    // public static double calculadoraDeImpostos(Imposto imposto) {
    // return imposto.calcular();
    // }
}
