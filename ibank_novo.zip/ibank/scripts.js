
const apiurl ="http://localhost:8080/pessoas";
let tiporequisicao = {
    method: 'GET'
}

function validaPessoa(){

    console.log(tiporequisicao);
    console.log("entrou aqui");
    let nomepessoa = document.getElementById("pessoa").value;
    document.getElementById('pessoa').value = "Pessoa encontrada"; 
    return false;
   
}

