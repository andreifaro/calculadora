package br.com.itau.techinsiders.ibank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbankApplication {

	public static void main(String[] args) {
		SpringApplication.run(IbankApplication.class, args);
	}
}
