package br.com.itau.techinsiders.ibank.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.techinsiders.ibank.models.Solicitacao;
import br.com.itau.techinsiders.ibank.repository.solicitaRepository;

@RestController
public class SolicitacaoController {
	

	 @Autowired
	 private solicitaRepository solicitaRepository;
	 
	@PostMapping(path = "/Solicitacao/add", consumes = "application/json", produces = "application/json")
	    public Solicitacao addSolicitacao(@RequestBody Solicitacao novasolicitacao) 
	 {
	    
	        Solicitacao SolicitacaoRegistrado = solicitaRepository.save(novasolicitacao);
	        return SolicitacaoRegistrado;	          
	        
	 }
	
	@GetMapping("/Solicitacao/Consulta")
	public Iterable<Solicitacao> allSolicitacao() {
		return solicitaRepository.findAll();
	}

}