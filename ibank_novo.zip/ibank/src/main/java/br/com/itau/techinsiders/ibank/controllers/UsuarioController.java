package br.com.itau.techinsiders.ibank.controllers;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.techinsiders.ibank.models.Usuario;
import br.com.itau.techinsiders.ibank.repository.UserRepository;

@RestController
public class UsuarioController {
	
		
	 @Autowired
	 private UserRepository UserRepository;
	 
	@PostMapping(path = "/Usuario/add", consumes = "application/json", produces = "application/json")
	    public Usuario addUsuario(@RequestBody Usuario novouser) 
	 {
	     
	        Usuario usuarioRegistado = UserRepository.save(novouser);
	        return usuarioRegistado;	          
	        
	 }
	
	   @GetMapping("/Usuario/login")
	    public Optional<Usuario> findUsuarioByracf(@RequestParam("racf") String racf){
	        Usuario user = UserRepository.findUsuarioByracf(racf);
	        return Optional.ofNullable(user);
	        //http://localhost:8080/pessoas/telefone?numero=(11) 912345673
	    }

}
