package br.com.itau.techinsiders.ibank.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Solicitacao implements Serializable {

    private static final long serialVersionUID = -4223473672168876751L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long idSolicitacao;
    public Long getIdSolicitacao() {
        return idSolicitacao;
    }
    public void setIdSolicitacao(Long idSolicitacao) {
        this.idSolicitacao = idSolicitacao;
    }
    
    @Column (name = "solicitacao_qtdeMemoria")
    private String qtdeMemoria;
    @Column (name = "solicitacao_racf")
    private String racf;
    @Column (name = "solicitacao_qtdeTrafego")
    private int qtdeTrafego;
    @Column (name = "solicitacao_qtdeHd")
    private int qtdeHd;
    @Column (name = "solicitacao_licenca1")
    private int licenca1;
    @Column (name = "solicitacao_licenca2")
    private int licenca2;
    @Column (name = "solicitacao_licenca3")
    private int licenca3;
    @Column (name = "solicitacao_valorTotal")
    private double valorTotal;
    @Column (name = "solicitacao_qtdeProcessador")
    private int qtdeProcessador;
    @Column (name = "solicitacao_qtdeMaquina")
    private int qtdeMaquina;
    @Column (name = "solicitacao_valorUnitarioMaquina")
    private double valorUnitarioMaquina;
  
    public String getQtdeMemoria() {
        return qtdeMemoria;
    }
    public void setQtdeMemoria(String qtdeMemoria) {
        this.qtdeMemoria = qtdeMemoria;
    }
    public String getRacf() {
        return racf;
    }
    public void setRacf(String racf) {
        this.racf = racf;
    }
    public int getQtdeTrafego() {
        return qtdeTrafego;
    }
    public void setQtdeTrafego(int qtdeTrafego) {
        this.qtdeTrafego = qtdeTrafego;
    }
    public int getQtdeHd() {
        return qtdeHd;
    }
    public void setQtdeHd(int qtdeHd) {
        this.qtdeHd = qtdeHd;
    }
    public int getLicenca1() {
        return licenca1;
    }
    public void setLicenca1(int licenca1) {
        this.licenca1 = licenca1;
    }
    public int getLicenca2() {
        return licenca2;
    }
    public void setLicenca2(int licenca2) {
        this.licenca2 = licenca2;
    }
    public int getLicenca3() {
        return licenca3;
    }
    public void setLicenca3(int licenca3) {
        this.licenca3 = licenca3;
    }
    public double getValorTotal() {
        return valorTotal;
    }
    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }
    public int getQtdeProcessador() {
        return qtdeProcessador;
    }
    public void setQtdeProcessador(int qtdeProcessador) {
        this.qtdeProcessador = qtdeProcessador;
    }
    public int getQtdeMaquina() {
        return qtdeMaquina;
    }
    public void setQtdeMaquina(int qtdeMaquina) {
        this.qtdeMaquina = qtdeMaquina;
    }
    public double getValorUnitarioMaquina() {
        return valorUnitarioMaquina;
    }
    public void setValorUnitarioMaquina(double valorUnitarioMaquina) {
        this.valorUnitarioMaquina = valorUnitarioMaquina;
    }
    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    
 
}