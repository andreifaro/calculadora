package br.com.itau.techinsiders.ibank.repository;
import br.com.itau.techinsiders.ibank.models.Usuario;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<Usuario, Long> {
		public Usuario findUsuarioByracf(String racf);

	}

