package br.com.itau.techinsiders.ibank.repository;
import br.com.itau.techinsiders.ibank.models.Solicitacao;

import org.springframework.data.repository.CrudRepository;

public interface solicitaRepository extends CrudRepository<Solicitacao, Long> {
		public Solicitacao findUsuarioByracf(String racf);

	}