package br.com.itau.techinsiders.ibank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IbankApplicationTests {

	@Test
	void contextLoads() {
	}

}
